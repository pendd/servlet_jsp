create FUNCTION add_sum1(num1 FLOAT,num2 FLOAT)
RETURN FLOAT
AS
--定义变量来接收返回值
v_result FLOAT;
BEGIN
  v_result := num1 + num2;
  RETURN v_result;
END;

--使用函数  (伪表)
SELECT add_sum1(20,30) FROM dual;
--使用数据表 （表中字段）
SELECT add_sum1(empno,mgr) FROM emp;

-----------------------------------------------------------------------------------------------------------------------------------

--书写一个获取时间单位,返回指定时间单位的值的函数 sysdate
--法一:
CREATE OR REPLACE FUNCTION return_time(vtime DATE,v_type VARCHAR2)
RETURN INT
AS
v_val INT;
BEGIN
  --判断类型
  CASE v_type
    WHEN 'YEAR' THEN
      SELECT to_char(vtime,'YYYY') INTO v_val FROM dual;
    WHEN 'MONTH' THEN
      SELECT to_char(vtime,'MM') INTO v_val FROM dual;
    WHEN 'DAY' THEN
      SELECT to_char(vtime,'DD') INTO v_val FROM dual;
    WHEN 'HOUR' THEN
      SELECT to_char(vtime,'HH24') INTO v_val FROM dual;
    WHEN 'MINUTE' THEN
      SELECT to_char(vtime,'MI') INTO v_val FROM dual;
    WHEN 'SECOND' THEN
      SELECT to_char(vtime,'SS') INTO v_val FROM dual;
  END CASE;
  RETURN v_val;
END;

--使用函数
SELECT return_time(SYSDATE,'MONTH') FROM dual;


--法二:
CREATE OR REPLACE FUNCTION getdate(v_date DATE,v_type VARCHAR2)
RETURN VARCHAR2
AS
v_newdate VARCHAR2(20);
BEGIN
  --将时间转换成字符类型
  SELECT to_char(v_date,'YYYYMMDDHH24MISS') INTO v_newdate FROM dual;
  --判断类型
  CASE v_type
    WHEN 'YEAR' THEN
      RETURN SUBSTR(v_newdate,1,4);
    WHEN 'MONTH' THEN
      RETURN substr(v_newdate,5,2);
    WHEN 'DAY' THEN
      RETURN SUBSTR(v_newdate,7,2);
    WHEN 'HOUR' THEN
      RETURN SUBSTR(v_newdate,9,2);
    WHEN 'MINUTE' THEN
      RETURN SUBSTR(v_newdate,11,2);
    WHEN 'SECOND' THEN
      RETURN SUBSTR(v_newdate,13);
  END CASE;
END;

--调用函数
SELECT getdate(SYSDATE,'MONTH') FROM dual;

-----------------------------------------------------------------------------------------------------------------------------------

/*
二、触发器

    什么是触发器？
       触发器是一种特殊的存储过程，在插入，修改或删除特定表中的数据时将会被触发执行，
       触发器在事件发生时是自动执行的，并且不能输入参数

   触发器的作用:
       1.安全性    限制用户的一些特殊操作 如：股票当天涨幅不能超过10%，指定时间才能访问某些数据表
       2.审计   如：跟踪用户的操作
       3.实现非标准的更为复杂的业务规则

   触发器的种类？
       1.DML触发器          进行DML语句操作时触发
       2.替换触发器        只能在视图上触发
       3.事件触发器        DDL和数据库事件触发

   创建触发器的语法:
       CREATE OR REPLACE TRIGGER 触发器名称
       触发时间  触发类型  ON  数据表  FOR EACH ROW
       BEGIN
	           --PL/SQL语句
       END;

  触发器的触发时间
      BEFORE
      AFTER
  触发器的触发类型
      INSERT
      UPDATE
      DELETE
  伪记录
    :NEW   新纪录  INSERT没有:OLD   UPDATE都存在
    :OLD   原纪录  DELETE没有:NEW
*/
-----------------------------------------------------------------------------------------------------------------------------------
--修改TOM用户的余额来触发事件
CREATE OR REPLACE TRIGGER mytrigger
BEFORE UPDATE ON bank FOR EACH ROW
BEGIN
  dbms_output.put_line('bank表在数据修改前被触发了,修改的当前金额是: ' || :old.balance || '修改后金额是: ' || :new.balance);
END;

--修改bank表
UPDATE bank SET balance = balance + 1000 WHERE username = 'TOM';
-----------------------------------------------------------------------------------------------------------------------------------
--禁止工作人员在休息日对员工信息表进行更改等操作【星期日、星期一】
--法一:
CREATE OR REPLACE TRIGGER my_trigger
BEFORE UPDATE ON emp
BEGIN
  IF to_char(SYSDATE,'day') = '星期日' OR to_char(SYSDATE,'day') = '星期五' THEN
     dbms_output.put_line('休息日不能修改数据');
  END IF;
END;

--修改emp表
UPDATE emp SET sal = 800 WHERE empno = 7369;


--法二:
CREATE OR REPLACE TRIGGER my_trigger1
BEFORE UPDATE ON emp
BEGIN
  IF to_char(SYSDATE,'day') = '星期日' OR to_char(SYSDATE,'day') = '星期五' THEN
     raise_application_error(-20001,'休息日不能修改数据');
  END IF;
END;

--修改emp表
UPDATE emp SET sal = 800 WHERE empno = 7369;


CREATE OR REPLACE TRIGGER my_trigger2
BEFORE UPDATE ON emp
BEGIN
  IF to_char(SYSDATE,'DY','nls_date_language = American') IN ('MON','SUN')  THEN
     raise_application_error(-20001,'休息日不能修改数据');
  END IF;
END;


-----------------------------------------------------------------------------------------------------------------------------------

/*
  ORACLE中常用的索引
      1.B-TREE索引
              它是适合大量的增删改查【联机事务处理】 它这里是不能包含or操作符的查询
      2.位图索引
              假设数据表中有一列其选择性非常窄，比如性别选择列，这就得使用位图索引，
              因为位图索引是为相异值很少的列而设的
      3.唯一索引
              主键列值要求列值是非空的，而唯一约束和唯一索引不要求列值非空
      4.反转键索引
             就是将索引键的值反转过来进行索引，索引的结构是没有变化的，只是索引值的存储方式有些不一样
             比如要进行索引的列值是:abcd ，反转过后存储的值是:dcba
      ...


  创建索引的语法1:
      CREATE INDEX 索引名称 ON 表名(列名) TABLESPACE 表空间名


      图书馆
       10000本书
        找一本《笑傲江湖》的书
         分类 武侠类 科学类 数学类 计算机类....
         第几个书架 第几排

        书签【索引 index】：就有书本存放的地址


  语法2: 复合索引
       CREATE INDEX 索引名称 ON 表名（列名1，列名2）

  使用索引的注意点：
      1.频繁查询的列适合建立索引
      2.查询列值范围较小的适合建立索引
      3.进行排序的列适合建立索引
      4.带有索引的数据表将占用更多的空间
      5.较小数据量的表不适合建立索引
      6.索引的使用将导致DML类语句操作效率降低

*/

-----------------------------------------------------------------------------------------------------------------------------------
--创建索引
CREATE INDEX inx_firstname ON employees(first_name) TABLESPACE SYSTEM;

CREATE INDEX inx_emp ON emp(ename,job);
-----------------------------------------------------------------------------------------------------------------------------------

/*
什么是视图？
    视图就是一张通过查询获取的虚拟表，视图中本身不存在数据，数据来自于视图对源表的映射引用，
    一张数据表可以根据不同的需要创建多个不同的视图

使用视图的优点:
    1.过滤表中的行数据
    2.阻止未经授权的用户访问敏感数据
    3.降低数据操作的复杂度
    4.可以将多个表空间中的数据抽象为一个逻辑数据

创建视图的语法:
    CREATE VIEW 视图名称 AS 查询语句
使用视图语法:
    SELECT * FROM 视图名称
*/
-----------------------------------------------------------------------------------------------------------------------------------
--创建视图
CREATE VIEW myview AS SELECT * FROM emp;
--使用视图
SELECT * FROM myview;

--视图是否可以影响到原表中的数据   可以
--由于视图中的数据是引用源表的数据，因此可以通过视图对源表进行增删改操作
--如果视图中存在多表数据，同一时间内只能更新一张表！


--授权
GRANT CREATE ANY VIEW TO testuser;

-----------------------------------------------------------------------------------------------------------------------------------
/*
  1.视图在多表更新时必须要存在键保留表
  2.键保留表即存在主表主键的外键表（两表并不是必须存在主外键关系）
  3.例如A B两表各有字段ID列 如果视图已A.ID=B.ID进行表联接，当修改A表数据的时候则A于B关联，
    A表的数据应依赖于B表，因此此时的A表相当于子表，B表为主表，若B表不存在主键则无法修改数据；
  4.对应的，如果修改B表数据的时候，B表依赖于A表，因此此时的B表相当于子表，A表为主表，
    因此要进行数据修改A表中必须存在主键

    结论：当使用视图进行多表联接修改时多表应都存在主键，并且使用主外键约束进行规范

*/
-----------------------------------------------------------------------------------------------------------------------------------
/*
    拓展:
        NVL函数的格式： NVL（expr1,expr2)
                  如果oracle第一个参数为空那么显示第二个参数的值，
                  如果第一个参数的值不为空，则显示第一个参数本来的值。



*/
SELECT ename,NVL(comm,-1) FROM emp;
/

