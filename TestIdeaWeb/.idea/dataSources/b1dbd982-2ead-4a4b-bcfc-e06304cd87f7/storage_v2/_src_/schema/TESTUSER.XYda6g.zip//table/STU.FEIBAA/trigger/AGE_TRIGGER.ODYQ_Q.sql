create trigger AGE_TRIGGER
  before update
  on STU
  for each row
  DECLARE
BEGIN
  IF :new.age > 40 OR :new.age <20 THEN
    raise_application_error(-20001,'修改失败,年龄必须在20-40之间');
    --dbms_output.put_line('修改失败,年龄必须在20-40之间');
  END IF;
END;
/

