create PROCEDURE p_mypro(v_empno emp.empno%TYPE,v_sub FLOAT)
AS
--接收工资
v_sal  FLOAT;
BEGIN
  SAVEPOINT a1;
  SELECT sal INTO v_sal FROM emp WHERE empno = v_empno;
  dbms_output.put_line('修改前工资为:' || v_sal);
  UPDATE emp SET sal = sal + v_sub WHERE empno = v_empno;
  SELECT sal INTO v_sal FROM emp WHERE empno = v_empno;
  IF v_sal < 0 THEN
    dbms_output.put_line('更新数据失败,工资不能为负！');
    --ROLLBACK TO a1;
    --COMMIT;
    ROLLBACK;
  ELSE
    dbms_output.put_line('修改后工资为:' || v_sal);
    COMMIT;
  END IF;
 -- OPEN my_emp FOR SELECT sal FROM emp;
END;
/

