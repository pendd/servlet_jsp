create PROCEDURE p_empid(v_empno emp.empno%TYPE)
AS
v_sal  FLOAT;
BEGIN
  UPDATE emp SET sal = sal WHERE empno = v_empno;
  --
  IF SQL%ROWCOUNT = 0 THEN
    dbms_output.put_line('case_not_found');
  ELSE
    SELECT sal INTO v_sal FROM emp WHERE empno = v_empno;
    IF v_sal < 1000 THEN
      v_sal := v_sal + 100;
    ELSIF v_sal < 2000 THEN
      v_sal := v_sal + 200;
    END IF;
    dbms_output.put_line(v_sal);
  END IF;
  COMMIT;
END;
/

