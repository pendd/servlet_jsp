create trigger STU_TRIGGER
  before insert
  on STU
  for each row
  DECLARE
BEGIN
  SELECT s_stuid.nextval INTO :new.stuid FROM dual;
END;
/

