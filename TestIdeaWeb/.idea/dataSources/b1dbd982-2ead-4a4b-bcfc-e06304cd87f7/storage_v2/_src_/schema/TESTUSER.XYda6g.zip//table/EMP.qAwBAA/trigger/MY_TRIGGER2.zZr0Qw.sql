create trigger MY_TRIGGER2
  before update
  on EMP
  BEGIN
  IF to_char(SYSDATE,'DY','nls_date_language = American') IN ('MON','SUN')  THEN
     raise_application_error(-20001,'休息日不能修改数据');
  END IF;
END;
/

