create FUNCTION getdate(v_date DATE,v_type VARCHAR2)
RETURN VARCHAR2
AS
v_newdate VARCHAR2(20);
BEGIN
  --将时间转换成字符类型
  SELECT to_char(v_date,'YYYYMMDDHH24MISS') INTO v_newdate FROM dual;
  --判断类型
  CASE v_type
    WHEN 'YEAR' THEN
      RETURN SUBSTR(v_newdate,1,4);
    WHEN 'MONTH' THEN
      RETURN substr(v_newdate,5,2);
    WHEN 'DAY' THEN
      RETURN SUBSTR(v_newdate,7,2);
    WHEN 'HOUR' THEN
      RETURN SUBSTR(v_newdate,9,2);
    WHEN 'MINUTE' THEN
      RETURN SUBSTR(v_newdate,11,2);
    WHEN 'SECOND' THEN
      RETURN SUBSTR(v_newdate,13);
  END CASE;
END;
/

