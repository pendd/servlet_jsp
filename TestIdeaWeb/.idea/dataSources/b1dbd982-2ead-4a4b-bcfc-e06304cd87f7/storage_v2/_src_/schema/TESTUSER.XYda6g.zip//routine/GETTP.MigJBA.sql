create function gettp(v_lc int,v_pj number,v_num number)
return number
as
v_tprice number;
begin
if v_num>0 then
v_tprice:=v_lc*v_pj;
return v_tprice;
else
dbms_output.put_line('软卧票已售完');
end if;
end;
/

