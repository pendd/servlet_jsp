create trigger MY_TRIGGER
  before update
  on EMP
  BEGIN
  SAVEPOINT a1;
  IF to_char(SYSDATE,'day') = '星期日' OR to_char(SYSDATE,'day') = '星期五' THEN
     dbms_output.put_line('休息日不能修改数据');
     ROLLBACK TO a1;
  END IF;
END;
/

