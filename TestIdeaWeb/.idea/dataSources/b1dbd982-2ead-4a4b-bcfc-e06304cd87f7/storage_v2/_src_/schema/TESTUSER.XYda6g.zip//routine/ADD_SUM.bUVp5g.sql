create PROCEDURE add_sum(v_num1 INT,v_num2 INT,v_result OUT INT)
AS
BEGIN
  v_result := v_num1 + v_num2;
  dbms_output.put_line(v_result);
END;
/

