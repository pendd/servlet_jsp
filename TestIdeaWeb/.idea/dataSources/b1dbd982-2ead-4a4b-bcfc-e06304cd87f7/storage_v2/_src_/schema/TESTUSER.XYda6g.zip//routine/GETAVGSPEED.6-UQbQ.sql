create function getavgspeed(v_number int,v_speedsum int)
return number
as
v_avgspeed number;
begin
  v_avgspeed:=v_speedsum/v_number;
  return v_avgspeed;
end;
/

