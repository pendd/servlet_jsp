create PROCEDURE p_getEname(vname IN VARCHAR2)
AS
v_ename  emp.ename%TYPE;
v_date   emp.hiredate%TYPE;
v_sal    emp.sal%TYPE;
BEGIN
  --查找的是SCOTT用户
  SELECT ename,hiredate,sal INTO v_ename,v_date,v_sal FROM emp WHERE ename = 'SCOTT';
  --打印输出
  dbms_output.put_line(v_ename || '  ' || v_date || '  ' || v_sal);
END;
/

