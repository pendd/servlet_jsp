create trigger MYTRIGGER
  before update
  on BANK
  for each row
  BEGIN
  dbms_output.put_line('bank表在数据修改前被触发了,修改的当前金额是: ' || :old.balance || '修改后金额是: ' || :new.balance);
END;
/

