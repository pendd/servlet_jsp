create PROCEDURE p_find_empinfo(v_dep_name VARCHAR2,c_empinfo OUT Sys_Refcursor)
AS
--根据部门编号
v_deptid INT;
BEGIN
  --根据部门名称查找部门编号
  SELECT department_id INTO v_deptid FROM departments WHERE department_name = v_dep_name;
  --根据id查找员工信息
  OPEN c_empinfo FOR SELECT * FROM employees WHERE department_id = v_deptid;
END;
/

