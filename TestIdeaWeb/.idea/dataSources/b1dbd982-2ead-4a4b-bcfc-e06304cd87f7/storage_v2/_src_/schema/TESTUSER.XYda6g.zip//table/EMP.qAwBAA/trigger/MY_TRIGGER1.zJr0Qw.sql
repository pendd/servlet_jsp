create trigger MY_TRIGGER1
  before update
  on EMP
  BEGIN
  IF to_char(SYSDATE,'day') = '星期日' OR to_char(SYSDATE,'day') = '星期五' THEN
     raise_application_error(-20001,'休息日不能修改数据');
  END IF;
END;
/

