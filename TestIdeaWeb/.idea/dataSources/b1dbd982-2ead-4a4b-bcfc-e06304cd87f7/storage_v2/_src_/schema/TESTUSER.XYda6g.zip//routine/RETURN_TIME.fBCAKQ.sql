create FUNCTION return_time(vtime DATE,v_type VARCHAR2)
RETURN INT
AS
v_val INT;
BEGIN
  --判断类型
  CASE v_type
    WHEN 'YEAR' THEN
      SELECT to_char(vtime,'YYYY') INTO v_val FROM dual;
    WHEN 'MONTH' THEN
      SELECT to_char(vtime,'MM') INTO v_val FROM dual;
    WHEN 'DAY' THEN
      SELECT to_char(vtime,'DD') INTO v_val FROM dual;
    WHEN 'HOUR' THEN
      SELECT to_char(vtime,'HH24') INTO v_val FROM dual;
    WHEN 'MINUTE' THEN
      SELECT to_char(vtime,'MI') INTO v_val FROM dual;
    WHEN 'SECOND' THEN
      SELECT to_char(vtime,'SS') INTO v_val FROM dual;
  END CASE;
  RETURN v_val;
END;
/

